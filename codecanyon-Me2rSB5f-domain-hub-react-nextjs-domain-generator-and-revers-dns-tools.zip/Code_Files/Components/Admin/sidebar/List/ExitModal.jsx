import CollapseItems from "../collapse-items";
import { LuSquareMenu } from "react-icons/lu";
import { useRouter } from "next/router";
export default function ExitModal() {
  const router = useRouter();
  return (
    <>
      <CollapseItems
        isActive={router.asPath.includes("mouse-exit")}
        icon={<LuSquareMenu color="white" />}
        items={[
          {
            text: "Popup Modal",
            link: "/admin/mouse-exit-modal",
            bold: router.query.route === "mouse-exit-modal",
          },
        ]}
        title="Popup Modal"
      />
    </>
  );
}
