import { useRouter } from "next/router";
import { FaHome } from "react-icons/fa";
import CollapseItems from "../collapse-items";

export default function HomePage() {
  const router = useRouter();
  return (
    <>
      <CollapseItems
        isActive={router.asPath.includes("domain-checker")}
        icon={<FaHome color="white" />}
        items={[
          {
            text: "Hero Section",
            link: "/admin/domain-checker-hero",
            bold: router.query.route === "domain-checker-hero",
          },
          {
            text: "Stats",
            bold: router.query.route === "domain-checker-stats",
            link: `/admin/domain-checker-stats`,
          },
          {
            text: "Call to Action",
            bold: router.query.route === "domain-checker-cta",
            link: `/admin/domain-checker-cta`,
          },
          {
            text: "Content",
            bold: router.query.route === "domain-checker-content",
            link: `/admin/domain-checker-content`,
          },
          {
            text: "Features Card",
            bold: router.query.route === "domain-checker-features",
            link: `/admin/domain-checker-features`,
          },
          {
            text: "Faq",
            bold: router.query.route === "domain-checker-faq",
            link: `/admin/domain-checker-faq`,
          },

          {
            text: "SEO",
            bold: router.query.route === "domain-checker-seo",
            link: `domain-checker-seo`,
          },
        ]}
        title="Home Page"
      />
    </>
  );
}
