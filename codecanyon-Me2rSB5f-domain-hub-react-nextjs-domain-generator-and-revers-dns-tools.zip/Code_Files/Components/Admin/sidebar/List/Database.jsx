import { useRouter } from "next/router";
import SidebarItem from "../sidebar-item";
import { GiBigGear } from "react-icons/gi";
export default function DataBases() {
  const router = useRouter();
  return (
    <>
      <SidebarItem
        isActive={router.asPath === "/admin/database"}
        title="Site Setting"
        href="/admin/database"
        icon={<GiBigGear color="white" />}
      />
    </>
  );
}
