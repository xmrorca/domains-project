import { useRouter } from "next/router";
import { FaWandMagicSparkles } from "react-icons/fa6";
import CollapseItems from "../collapse-items";
import { v4 as uuidv4 } from "uuid";
export default function AiDomainGenerator() {
  const router = useRouter();
  return (
    <>
      <CollapseItems
        isActive={router.asPath.includes("domain-suggest")}
        icon={<FaWandMagicSparkles color="white" />}
        items={[
          {
            text: "Hero",
            link: "/admin/domain-suggest-hero",
            bold: router.query.route === "domain-suggest-hero",
          },
          {
            text: "Stats",
            bold: router.query.route === "domain-suggest-stats",
            link: `/admin/domain-suggest-stats`,
          },
          {
            text: "CTA",
            bold: router.query.route === "domain-suggest-cta",
            link: `/admin/domain-suggest-cta`,
          },
          {
            text: "Content",
            bold: router.query.route === "domain-suggest-content",
            link: `/admin/domain-suggest-content`,
          },
          {
            text: "Features",
            bold: router.query.route === "domain-suggest-features",
            link: `/admin/domain-suggest-features`,
          },
          // {
          //   text: "Pricing",
          //   bold: router.query.route === "domain-suggest-pricing",
          //   link: `/admin/domain-suggest-pricing`,
          // },
          {
            text: "Faq",
            bold: router.query.route === "domain-suggest-faq",
            link: `/admin/domain-suggest-faq`,
          },
          // {
          //   text: "Ads",
          //   bold: router.query.route === "domain-suggest-ads",
          //   link: `/admin/domain-suggest-ads`,
          // },
          {
            text: "SEO",
            bold: router.query.route === "domain-suggest-seo",
            link: `/admin/domain-suggest-seo`,
          },
        ]}
        title="Domain Suggest"
      />
    </>
  );
}
