import { useRouter } from "next/router";
import CollapseItems from "../collapse-items";
import { MdPolicy } from "react-icons/md";

export default function PrivacyPolicy() {
  const router = useRouter();
  return (
    <>
      <CollapseItems
        isActive={router.asPath.includes("privacy")}
        icon={<MdPolicy color="white" />}
        items={[
          {
            text: "Privacy Policy",
            link: "/admin/privacy-policy",
            bold: router.query.route === "privacy-policy",
          },
        ]}
        title="Privacy Policy"
      />
    </>
  );
}
