import { useRouter } from "next/router";
import SidebarItem from "../sidebar-item";
import { FaRegImages } from "react-icons/fa6";
export default function Logo() {
  const router = useRouter();
  return (
    <>
      <SidebarItem
        isActive={router.asPath === "/admin/logo"}
        title="Logo"
        href="/admin/logo"
        icon={<FaRegImages color="white" />}
      />
    </>
  );
}
