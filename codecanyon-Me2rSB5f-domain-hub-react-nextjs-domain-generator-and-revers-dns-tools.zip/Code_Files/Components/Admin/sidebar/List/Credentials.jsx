import { useRouter } from "next/router";
import SidebarItem from "../sidebar-item";
import { RiLockPasswordFill } from "react-icons/ri";
export default function Credentials() {
  const router = useRouter();
  return (
    <>
      <SidebarItem
        isActive={router.asPath === "/admin/credentials"}
        title="Credentials"
        href="/admin/credentials"
        icon={<RiLockPasswordFill color="white" />}
      />
    </>
  );
}
