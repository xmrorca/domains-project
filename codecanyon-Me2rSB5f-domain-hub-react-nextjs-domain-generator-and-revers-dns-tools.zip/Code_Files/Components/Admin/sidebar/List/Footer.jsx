import { useRouter } from "next/router";
import { RiLayoutBottom2Line } from "react-icons/ri";
import CollapseItems from "../collapse-items";

export default function Footer() {
  const router = useRouter();
  return (
    <>
      <CollapseItems
        isActive={router.asPath.includes("footer")}
        icon={<RiLayoutBottom2Line color="white" />}
        items={[
          {
            text: "Social Links",
            link: "/admin/footer",
            bold: router.query.route === "footer",
          },
        ]}
        title="Footer"
      />
    </>
  );
}
