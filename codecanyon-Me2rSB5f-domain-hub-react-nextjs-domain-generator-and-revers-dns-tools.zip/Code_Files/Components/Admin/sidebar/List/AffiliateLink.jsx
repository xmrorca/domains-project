import { useRouter } from "next/router";
import { IoIosLink } from "react-icons/io";
import CollapseItems from "../collapse-items";

export default function AffiliateLink() {
  const router = useRouter();
  return (
    <>
      <CollapseItems
        isActive={router.asPath.includes("affiliate-links")}
        icon={<IoIosLink color="white" />}
        items={[
          {
            text: "Affiliate Links",
            link: "/admin/affiliate-links",
            bold: router.query.route === "affiliate-links",
          },
        ]}
        title="Affiliate Links"
      />
    </>
  );
}
