import {
  Button,
  Card,
  CardBody,
  CardHeader,
  Chip,
  Divider,
  Link,
  Spacer,
  Textarea,
} from "@heroui/react";
import axios from "axios";
import { useEffect, useState } from "react";
import toast, { Toaster } from "react-hot-toast";
export default function RobotTxt() {
  const [robotTxt, setRobotTxt] = useState("");
  const [loading, setLoading] = useState(false);
  const [loading2, setLoading2] = useState(false);
  const token = JSON.parse(localStorage.getItem("lg_tk"));

  const handleSave = (e) => {
    setLoading(true);
    axios
      .post("/api/robot-txt", {
        robotTxt,
        token,
      })
      .then((res) => {
        setLoading(false);
        toast(res.data?.message, { position: "bottom-right" });
      })
      .catch((err) => {
        setLoading(false);
        toast.error("Some Error Occurred", { position: "bottom-right" });
      });
  };

  const generateSitemap = (e) => {
    setLoading2(true);
    axios
      .post("/api/sitemap", {
        token,
      })
      .then((res) => {
        setLoading2(false);
        toast(res.data?.message, { position: "bottom-right" });
      })
      .catch((err) => {
        setLoading2(false);
        console.log(err);
        toast.error("Some Error Occurred", { position: "bottom-right" });
      });
  };

  useEffect(() => {
    axios.get("/api/robot-txt").then((res) => {
      if (res.data?.status) {
        setRobotTxt(res.data?.data);
      }
    });
  }, []);

  return (
    <Card className="m-4 !border-0" shadow="lg">
      <Toaster />
      <CardHeader>
        <h4 className="text-xl font-semibold text-violet-700">
          Sitemap and Robots.txt Setting
        </h4>
      </CardHeader>
      <Divider />
      <CardBody>
        <Chip variant="flat" radius="sm" color="warning">
          The sitemap.xml file needs to be updated manually whenever your site's
          content changes. Please check your sitemap below.
        </Chip>
        <Spacer y="2" />

        <div>
          <Link
            href={`${window.location.origin}/sitemap.xml`}
            isExternal
            isBlock
            showAnchorIcon
            color="secondary"
          >
            {`${window.location.origin}/sitemap.xml`}
          </Link>
          <Spacer y="2" />
          <Button
            size="md"
            color="secondary"
            variant="shadow"
            isLoading={loading2}
            onPress={generateSitemap}
          >
            Generate Sitemap
          </Button>
        </div>
        <Spacer y="4" />
        <Textarea
          variant="bordered"
          label="Robots.txt Description"
          labelPlacement="outside"
          placeholder="Enter your Robot Txt File Description"
          className="col-span-"
          minRows={10}
          value={robotTxt}
          onChange={(e) => setRobotTxt(e.target.value)}
        />

        <Spacer y="4" />
        <div>
          <Button
            size="md"
            color="secondary"
            variant="shadow"
            isLoading={loading}
            onPress={handleSave}
          >
            Save robots.txt
          </Button>
        </div>
      </CardBody>
    </Card>
  );
}
