import {
  Button,
  Card,
  CardBody,
  CardHeader,
  Divider,
  Input,
  Spacer,
  Textarea,
} from "@heroui/react";
import axios from "axios";
import { useEffect, useState } from "react";
import toast, { Toaster } from "react-hot-toast";

export default function Footer() {
  const [copyRight, setCopyRight] = useState("");
  const [twitterHandle, setTwitterHandle] = useState("");
  const [instagramHandle, setInstagramHandle] = useState("");
  const [facebookHandle, setFacebookHandle] = useState("");
  const [youtubeHandle, setYoutubeHandle] = useState("");
  const [col1Title, setCol1Title] = useState("");
  const [col1Links, setCol1Links] = useState("");

  const [col2Title, setCol2Title] = useState("");
  const [col2Links, setCol2Links] = useState("");

  const [col3Title, setCol3Title] = useState("");
  const [col3Links, setCol3Links] = useState("");

  const [loading, setLoading] = useState(false);

  const token = JSON.parse(localStorage.getItem("lg_tk"));
  const handleSave = (e) => {
    setLoading(true);
    axios
      .post("/api/footer/footer-content", {
        copyRight,
        twitterHandle,
        instagramHandle,
        facebookHandle,
        youtubeHandle,
        col1Title,
        col1Links,
        col2Title,
        col2Links,
        col3Title,
        col3Links,
        token,
      })
      .then((res) => {
        setLoading(false);
        toast(res.data?.message, { position: "bottom-right" });
      })
      .catch((err) => {
        setLoading(false);
        toast.error("Some Error Occurred", { position: "bottom-right" });
      });
  };

  useEffect(() => {
    axios.get("/api/footer/footer-content").then((res) => {
      if (res.data?.footerContent) {
        setCopyRight(res.data?.footerContent?.copyRight);

        setTwitterHandle(res.data?.footerContent?.twitterHandle);
        setInstagramHandle(res.data?.footerContent?.instagramHandle);
        setFacebookHandle(res.data?.footerContent?.facebookHandle);
        setYoutubeHandle(res.data?.footerContent?.youtubeHandle);

        setCol1Title(res.data?.footerContent?.col1Title);
        setCol1Links(res.data?.footerContent?.col1Links);

        setCol2Title(res.data?.footerContent?.col2Title);
        setCol2Links(res.data?.footerContent?.col2Links);

        setCol3Title(res.data?.footerContent?.col3Title);
        setCol3Links(res.data?.footerContent?.col3Links);
      }
    });
  }, []);

  return (
    <Card className="m-4 !border-0" shadow="lg">
      <Toaster />
      <CardHeader>
        <h4 className="text-xl font-semibold text-violet-700">
          Footer Component
        </h4>
      </CardHeader>
      <Divider />
      <CardBody>
        <div className="grid grid-cols-3 gap-2">
          <div>
            <Input
              value={col1Title}
              onChange={(e) => setCol1Title(e.target.value)}
              type="text"
              label="Column 1 Title"
            />
            <Spacer y="2" />
            <Textarea
              minRows={10}
              value={col1Links}
              onChange={(e) => setCol1Links(e.target.value)}
              type="text"
              label="Col 1 Links | text->/path.com"
            />
          </div>
          <div>
            <Input
              value={col2Title}
              onChange={(e) => setCol2Title(e.target.value)}
              type="text"
              label="Column 2 Title"
            />
            <Spacer y="2" />
            <Textarea
              minRows={10}
              value={col2Links}
              onChange={(e) => setCol2Links(e.target.value)}
              type="text"
              label="Col 2 Links | text->/path.com"
            />
          </div>
          <div>
            <Input
              value={col3Title}
              onChange={(e) => setCol3Title(e.target.value)}
              type="text"
              label="Column 3 Title"
            />
            <Spacer y="2" />
            <Textarea
              minRows={10}
              value={col3Links}
              onChange={(e) => setCol3Links(e.target.value)}
              type="text"
              label="Col 3 Links | text->/path.com"
            />
          </div>
        </div>
        <Spacer y="4" />
        <div>
          <Input
            value={copyRight}
            onChange={(e) => setCopyRight(e.target.value)}
            type="text"
            label="Copyright Text"
          />
          <Spacer y="1" />
          <Input
            value={twitterHandle}
            onChange={(e) => setTwitterHandle(e.target.value)}
            type="text"
            label="X handle"
          />
          <Spacer y="1" />
          <Input
            value={instagramHandle}
            onChange={(e) => setInstagramHandle(e.target.value)}
            type="text"
            label="Instagram handle"
          />
          <Spacer y="1" />
          <Input
            value={facebookHandle}
            onChange={(e) => setFacebookHandle(e.target.value)}
            type="text"
            label="Facebook handle"
          />
          <Spacer y="1" />
          <Input
            value={youtubeHandle}
            onChange={(e) => setYoutubeHandle(e.target.value)}
            type="text"
            label="Youtube handle"
          />
          <Spacer y="4" />
          <Button
            size="md"
            color="secondary"
            variant="shadow"
            isLoading={loading}
            onPress={handleSave}
          >
            Save
          </Button>
        </div>
      </CardBody>
    </Card>
  );
}
