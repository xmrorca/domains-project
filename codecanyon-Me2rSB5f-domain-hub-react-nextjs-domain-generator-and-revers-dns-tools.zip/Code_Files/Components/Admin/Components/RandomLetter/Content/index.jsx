import Content from "../../../../ReUsable/Admin/Content";

export default function Contents() {
  return <Content dbCollection={"random-letter"} item={"content"} />;
}
