import Backend from "./Backend";
import Table from "./Table";
export default function AdminStats() {
  return (
    <div>
      <Backend />
      <Table />
    </div>
  );
}
