import Content from "../../../../ReUsable/Admin/Content";

export default function Contents() {
  return <Content dbCollection={"hosting-location"} item={"content"} />;
}
