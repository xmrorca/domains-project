import {
  Card,
  CardBody,
  CardHeader,
  Divider,
  Input,
  Spacer,
} from "@heroui/react";
import Hero from "./Hero";
// import CTA from "./CTA";
import FeatureCard from "./FeatureCard";
import Faq from "./Faq";
import Pricing from "./Pricing";
import Testimonial from "./Testmonial";
export default function LandingPage() {
  return (
    // <div className="p-3">
    //   <Card>
    //     <CardHeader>
    //       <h5>Home Page Settings</h5>
    //     </CardHeader>
    //     <Divider />
    //     <CardBody>
    //       <Hero />
    //     </CardBody>
    //   </Card>
    //   <Spacer />
    //   <Card>
    //     <CardHeader>Call to Action</CardHeader>
    //     <Divider />
    //     <CardBody>
    //       <CTA />
    //     </CardBody>
    //   </Card>
    //   <Card>
    //     <CardHeader>Feature Cards</CardHeader>
    //     <Divider />
    //     <CardBody>
    //       <FeatureCard />
    //     </CardBody>
    //   </Card>
    //   <Card>
    //     <CardHeader>Faq List</CardHeader>
    //     <Divider />
    //     <CardBody>
    //       <Faq />
    //     </CardBody>
    //   </Card>
    //   <Card>
    //     <CardHeader>Pricing List</CardHeader>
    //     <Divider />
    //     <CardBody>
    //       <Pricing />
    //     </CardBody>
    //   </Card>
    //   <Card>
    //     <CardHeader>User Testimonial</CardHeader>
    //     <Divider />
    //     <CardBody>
    //       <Testimonial />
    //     </CardBody>
    //   </Card>
    // </div>
    <></>
  );
}
