import Content from "../../../../ReUsable/Admin/Content";

export default function Contents() {
  return <Content dbCollection={"ai-generator"} item={"content"} />;
}
