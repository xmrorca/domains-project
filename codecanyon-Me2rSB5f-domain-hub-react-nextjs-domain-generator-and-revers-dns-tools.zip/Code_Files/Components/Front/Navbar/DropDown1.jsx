import {
  Button,
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownTrigger,
  NavbarItem,
} from "@heroui/react";
import {
  ChevronDown,
  Lock,
  Activity,
  Flash,
  Server,
  TagUser,
  Scale,
  Words,
  Ai1,
  Ai2,
} from "./Icons.jsx";
import Link from "next/link.js";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faMagnifyingGlass,
  faMagnifyingGlassArrowRight,
} from "@fortawesome/free-solid-svg-icons";
import { faMagicWandSparkles } from "@fortawesome/free-solid-svg-icons";
export default function DropDown1() {
  const icons = {
    chevron: <ChevronDown fill="currentColor" size={16} />,
    scale: <Scale className="text-warning" fill="currentColor" size={30} />,
    lock: <Lock className="text-success" fill="currentColor" size={30} />,
    activity: (
      <Activity className="text-secondary" fill="currentColor" size={30} />
    ),
    flash: <Flash className="text-primary" fill="currentColor" size={30} />,
    words: <Words className="text-primary" fill="currentColor" size={30} />,
    ai1: <Ai1 className="text-primary" fill="currentColor" size={30} />,
    ai2: <Ai2 className="text-primary" fill="" size={30} />,
    server: <Server className="text-success" fill="currentColor" size={30} />,
    user: <TagUser className="text-danger" fill="currentColor" size={30} />,
  };
  return (
    <Dropdown>
      <DropdownTrigger>
        <Button
          disableRipple
          className="p-0 bg-transparent data-[hover=true]:bg-transparent text-md"
          endContent={icons.chevron}
          radius="sm"
          variant="light"
        >
          Domain
        </Button>
      </DropdownTrigger>

      <DropdownMenu
        aria-label="Dropdown Variants"
        className="max-w-[340px]"
        itemClasses={{
          base: "gap-4",
        }}
      >
        <DropdownItem
          classNames={{ description: "text-wrap" }}
          as={Link}
          href="/domain-gpt"
          key="domain-search"
          description="Generate domain names based on ChatGPT API with your custom prompt."
          startContent={icons.ai1}
        >
          Domain GPT
        </DropdownItem>
        <DropdownItem
          classNames={{ description: "text-wrap" }}
          as={Link}
          href="/domain-name-suggest"
          key="ai-domain-generator"
          description="AI based domain suggestion tool with availability checks. Supports 500+ extensions."
          startContent={
            <FontAwesomeIcon
              icon={faMagicWandSparkles}
              size="xl"
              color="#10375C"
            />
          }
        >
          Domain Suggest
        </DropdownItem>

        <DropdownItem
          classNames={{ description: "text-wrap" }}
          as={Link}
          href="/random-word-generator"
          key="usage_metrics"
          description="Generate random english dicrionary words powered by AI. Add prefix and suffix words."
          startContent={icons.words}
        >
          Random Word Generator
        </DropdownItem>
        <DropdownItem
          classNames={{ description: "text-wrap" }}
          as={Link}
          href="/random-letter-generator"
          key="production_ready"
          description="Generate random english letters, numbers, and alpha-numaric domain names."
          startContent={icons.flash}
        >
          Random Letter Generator
        </DropdownItem>
        {/* <DropdownItem
          as={Link}
          href="/who-is-hosting"
          key="99_uptime"
          description="Check who is hosted a website. Webhosting provider checker."
          startContent={icons.server}
        >
          Web Hosting Checker
        </DropdownItem> */}
      </DropdownMenu>
    </Dropdown>
  );
}
