import Link from "next/link";
import DropDown3 from "./DropDown3";
import DropDown1 from "./DropDown1";
import DropDown2 from "./DropDown2";
import DarkModeSwitch from "../../Admin/navbar/darkmodeswitch";
import { useEffect, useState } from "react";
import axios from "axios";
import {
  Button,
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownTrigger,
  Image,
  Navbar,
  NavbarBrand,
  NavbarContent,
  NavbarItem,
  NavbarMenu,
  NavbarMenuItem,
  NavbarMenuToggle,
} from "@heroui/react";
import { useDispatch, useSelector } from "react-redux";
import {
  setAffiliateLinks,
  setBannerAds,
  setGoogleAdsense,
} from "../../../Redux/reducer";
export default function NavBar() {
  const [logo, setLogo] = useState("");
  const dispatch = useDispatch();
  const bannerAds = useSelector((state) => state?.bannerAds);
  const googleAds = useSelector((state) => state?.googleAdsense);

  useEffect(() => {
    axios.get("/api/logo/logo").then((res) => {
      setLogo(res.data);
    });

    if (!bannerAds) {
      axios
        .get("/api/banner-ads")
        .then((res) => dispatch(setBannerAds(res.data)))
        .catch((err) => console.log(err));
    }

    if (!googleAds) {
      axios
        .get("/api/adsense")
        .then((res) => dispatch(setGoogleAdsense(res.data)))
        .catch((err) => console.log(err));
    }

    axios.get("/api/affiliate-link").then((res) => {
      dispatch(setAffiliateLinks(res.data?.affiliateLink));
    });
  }, []);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <Navbar
      // position="static"
      shouldHideOnScroll
      isMenuOpen={isMenuOpen}
      onMenuOpenChange={setIsMenuOpen}
    >
      <NavbarContent className="sm:hidden" justify="start">
        <NavbarMenuToggle
          aria-label={isMenuOpen ? "Close menu" : "Open menu"}
        />
      </NavbarContent>

      <NavbarContent className="sm:hidden pr-3" justify="center">
        <NavbarBrand>
          <Link className="" href="/" aria-label="Brand">
            <Image
              width={250}
              // height={50}
              alt="Your site logo"
              src="/images/logo/logo/logo.png"
            />
          </Link>
        </NavbarBrand>
      </NavbarContent>

      <NavbarContent className="hidden sm:flex gap-4" justify="center">
        <NavbarBrand>
          <Link className="" href="/" aria-label="Brand">
            <Image
              width={250}
              // height={50}
              alt="Your site logo"
              src="/images/logo/logo/logo.png"
            />
          </Link>
        </NavbarBrand>
      </NavbarContent>

      <NavbarContent justify="end">
        <NavbarItem className="hidden lg:flex">
          <DarkModeSwitch size="sm" />
        </NavbarItem>
        <NavbarItem className="hidden lg:flex">
          <DropDown1 />
        </NavbarItem>
        <NavbarItem className="hidden lg:flex">
          <DropDown2 />
        </NavbarItem>
        <NavbarItem className="hidden lg:flex">
          <DropDown3 />
        </NavbarItem>
        <NavbarItem className="hidden lg:flex">
          <Link href="/blog">Blog</Link>
        </NavbarItem>
        <NavbarItem className="hidden lg:flex">
          <Link href="saved-domains">Favourites</Link>
        </NavbarItem>
      </NavbarContent>

      <NavbarMenu className="flex flex-col items-center">
        <NavbarMenuItem className="list-none">
          <DarkModeSwitch size="sm" />
        </NavbarMenuItem>
        <NavbarMenuItem className="list-none">
          <DropDown1 />
        </NavbarMenuItem>
        <NavbarMenuItem className="list-none">
          <DropDown2 />
        </NavbarMenuItem>
        <NavbarMenuItem className="list-none">
          <DropDown3 />
        </NavbarMenuItem>
        <NavbarMenuItem className="list-none">
          <Link href="/blog">Blog</Link>
        </NavbarMenuItem>
        <NavbarMenuItem className="list-none">
          <Link href="saved-domains">Favourites</Link>
        </NavbarMenuItem>
      </NavbarMenu>
    </Navbar>
  );
}
