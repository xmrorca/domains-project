import {
  Modal,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
} from "@heroui/react";

import TldList from "./TldList";
import Ads from "../../Ads";
export default function TldModal({ data, isOpen, onOpenChange }) {
  // console.log(data);
  return (
    <Modal
      isOpen={isOpen}
      onOpenChange={onOpenChange}
      size="4xl"
      hideCloseButton
      scrollBehavior="outside"
      disableAnimation
    >
      <ModalContent>
        {(onClose) => (
          <>
            <ModalHeader className="py-2">
              <h3>TLDs</h3>
            </ModalHeader>

            <ModalBody>
              {isOpen && <TldList domains={data} />}
              <Ads />
            </ModalBody>
            <ModalFooter>
              <Button color="danger" onPress={onClose}>
                Close
              </Button>
            </ModalFooter>
          </>
        )}
      </ModalContent>
    </Modal>
  );
}
