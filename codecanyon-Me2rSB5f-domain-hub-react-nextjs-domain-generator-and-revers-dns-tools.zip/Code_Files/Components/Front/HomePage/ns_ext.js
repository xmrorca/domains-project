const ns_ext = `
com
net
org
xyz
cc
info
academy
accountant
accountants
africa
agency
apartments
app
art
asia
attorney
auction
auto
autos
bank
bargains
beauty
best
bid
bio
biz
blog
bond
bot
build
builders
business
buzz
cab
cafe
cam
capital
car
cards
care
cars
cash
catering
center
ceo
chat
cheap
city
cleaning
cloud
club
codes
coffee
college
company
consulting
cooking

cool

country

coupons
courses

credit
date
day

dealer
deals

delivery
desi
design
dev
diet
digital
direct
directory
discount
doctor
domains
download
email
enterprises
estate


events
expert
express
family
fan
fans
fashion
feedback
finance
fish
fishing
fit
fitness
flights
football

forex
forsale
forum
foundation


fun
fund
furniture
fyi
game



gift





global



gold

golf



graphics

green


group


guide

guru

hair




health
healthcare
help







holiday

homes



hospital
host
hosting
how




inc

ink
institute
insurance

international

investments


jewelry

jobs







kitchen

land

law
lawyer

lease

legal

life




limited


link

live

llc

loan

london


love

ltd



luxury





makeup

management


market
marketing
markets


media




men
menu




mobi


money


mortgage
name
new
news

nyc
one


online



page

photo
pics

pictures


pizza
place


plus



press

pro

 

promo
properties
property

radio

realestate
red



rent
rentals
repair
report

rest
restaurant
review
reviews


rich

run





sale






school


science


security



services




shop
shopping

show


site
social

software

tax


team
tech
tickets
tips
today

tools
top


tours

trade
trading
training
travel

university

vip

vote

watch

website

wiki

world

xyz



yoga

`;

module.exports = { ns_ext };
