export default function Content() {
  return (
    <>
      <h4>Text Editor</h4>
    </>
  );
}
