import { useRouter } from "next/router";

import Seo from "../../Admin/Components/WhoIsHosting/Seo";
import CTA from "../../Admin/Components/AiDomainGenerator/CTA";
import HeroForm from "../../Admin/Components/AiDomainGenerator/HeroForm";
import Content from "../../Admin/Components/AiDomainGenerator/Content";
import FAQ from "../../Admin/Components/AiDomainGenerator/FAQ";
import Features from "../../Admin/Components/AiDomainGenerator/Features";
import Stats from "../../Admin/Components/AiDomainGenerator/Stats";
import BannerAds from "../../Admin/Components/AiDomainGenerator/BannerAds";

export default function AiDomainGenerator() {
  const router = useRouter();
  const route = router.query.route;
  return (
    <>
      {route === "domain-suggest-hero" ? (
        <HeroForm />
      ) : route === "domain-suggest-cta" ? (
        <CTA />
      ) : route === "domain-suggest-content" ? (
        <Content />
      ) : route === "domain-suggest-faq" ? (
        <FAQ />
      ) : route === "domain-suggest-features" ? (
        <Features />
      ) : route === "domain-suggest-stats" ? (
        <Stats />
      ) : route === "domain-suggest-banner-ads" ? (
        <BannerAds />
      ) : route === "domain-suggest-seo" ? (
        <Seo dbCollection={"ai-generator"} />
      ) : (
        ""
      )}
    </>
  );
}
