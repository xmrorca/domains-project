import { useRouter } from "next/router";

import Seo from "../../Admin/Components/WhoIsHosting/Seo";
import CTA from "../../Admin/Components/LandingPage/CTA";
import HeroForm from "../../Admin/Components/LandingPage/HeroForm";
import FAQ from "../../Admin/Components/LandingPage/FAQ";
import Features from "../../Admin/Components/LandingPage/Features";
import Stats from "../../Admin/Components/LandingPage/Stats";
import BannerAds from "../../Admin/Components/LandingPage/BannerAds";
import Content from "../../Admin/Components/LandingPage/Content";

export default function HomePage() {
  const router = useRouter();
  const route = router.query.route;
  return (
    <>
      {route === "domain-checker-hero" ? (
        <HeroForm />
      ) : route === "domain-checker-content" ? (
        <Content />
      ) : route === "domain-checker-cta" ? (
        <CTA />
      ) : route === "domain-checker-faq" ? (
        <FAQ />
      ) : route === "domain-checker-features" ? (
        <Features />
      ) : route === "domain-checker-stats" ? (
        <Stats />
      ) : route === "domain-checker-banner-ads" ? (
        <BannerAds />
      ) : route === "domain-checker-seo" ? (
        <Seo dbCollection={"home-page"} />
      ) : (
        ""
      )}
    </>
  );
}
