import { useRouter } from "next/router";
import PrivacyPolicy from "../../Admin/Components/PrivacyPolicy";

export default function PrivacyPolicys() {
  const router = useRouter();
  const route = router.query.route;
  return <>{route === "privacy-policy" ? <PrivacyPolicy /> : ""}</>;
}
