import {
  Card,
  CardBody,
  CardFooter,
  Link,
  Progress,
  useDisclosure,
} from "@heroui/react";
// import DomainModal from "./DomainModal";
import { useSelector } from "react-redux";
import { useState } from "react";
import DomainModal from "../DomainList/DomainModal";
const gradients = [
  "from-[#4F46E5] to-[#E114E5]",
  "from-pink-500 to-violet-600",
  "from-emerald-500 to-lime-600",
  "from-sky-400 to-blue-500",
  "from-yellow-500  via-red-500 to-green-500",
  "from-lime-400 to-lime-500",
  "from-violet-600  via-red-500 to-indigo-600",
  "from-rose-400 to-red-500",
  "from-sky-400 to-blue-500",
];

const getRandomGradient = () =>
  gradients[Math.floor(Math.random() * gradients.length)];

export default function DomainCard({ domains }) {
  const affiliateLinks = useSelector((state) => state?.affiliateLinks);
  const { isOpen, onOpen, onOpenChange } = useDisclosure();
  const [modalData, setModalData] = useState("");
  const link = (x) => {
    if (x?.availability === "available") {
      return affiliateLinks?.affiliateProvider === "godaddy"
        ? `${affiliateLinks?.godaddyLink}https://in.godaddy.com/domainsearch/find?domainToCheck=${x?.domain}`
        : affiliateLinks?.affiliateProvider === "namecheap"
        ? `${affiliateLinks?.nameCheapLink}https%3A%2F%2Fwww.namecheap.com%2Fdomains%2Fregistration%2Fresults%2F%3Fdomain%3D${x.domain}&afftrack=`
        : affiliateLinks?.affiliateProvider === "domain.com"
        ? `https://www.domain.com/registration/?flow=domainDFE&search=${x?.domain}${affiliateLinks?.domainLink}`
        : affiliateLinks?.affiliateProvider === "dynadot"
        ? `${affiliateLinks?.dynadotLink}https%3A%2F%2Fwww.dynadot.com%2Fdomain%2Fsearch.html%3Fdomain%3D${x?.domain}`
        : affiliateLinks?.otherLink;
    }
    return `${affiliateLinks?.godaddyLink}https://in.godaddy.com/domainsearch/find?domainToCheck=${x?.domain}`;
  };
  const openModal = (data) => {
    onOpen();
    setModalData(data);
  };
  return (
    <div className="">
      <DomainModal
        onOpenChange={onOpenChange}
        isOpen={isOpen}
        data={modalData}
      />
      {domains?.length == 0 && (
        <Progress
          size="sm"
          color="primary"
          isIndeterminate
          aria-label="Loading..."
          className="w-full "
        />
      )}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols- lg:grid-cols-3 xl:grid-cols-4 gap-4 my-2 px-3 lg:px-20 ">
        {domains?.map((x, i) => {
          const randomGradient = getRandomGradient();

          return (
            <Card className="min-h-40 2xl:min-h-52 box-shadow dark:hover:shadow-lg dark:hover:shadow-slate-500">
              <CardBody
                onClick={() => openModal(x)}
                className="flex justify-center items-center custom-scrollbar overflow-hidden py-0"
              >
                <p
                  onClick={() => openModal(x)}
                  className={`${
                    x?.domain?.split(".")?.[0]?.length > 17
                      ? `text-[1.4rem]`
                      : `text-2xl`
                  } 2xl:text-3xl font-semibold text-transparent bg-clip-text bg-gradient-to-r ${randomGradient} text-center p-0 mt-1`}
                >
                  {x?.domain?.split(".")?.[0]}
                </p>
              </CardBody>
              <CardFooter
                as={Link}
                isExternal
                href={link(x)}
                className="absolut flex justify-between bg-black/5 bottom-0 z-10 mt-0 border-b-1 border-b-gray-300 dark:border dark:border-gray-800"
              >
                <p className="text-tiny 2xl:text-sm text-black/60 dark:text-gray-600">
                  {x?.domain}
                </p>
                <p
                  href={link(x)}
                  className="text-tiny 2xl:text-sm text-black/60 dark:text-gray-600"
                >
                  Get Now
                </p>
              </CardFooter>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
